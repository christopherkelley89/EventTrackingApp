package com.zybooks.christopherkelley_eventtrackingapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class EventAdapter extends BaseAdapter {
    private Context context;
    private List<Event> events;

    /**
     * Constructs an EventAdapter.
     *
     * @param context The context of the calling activity or fragment.
     * @param events  The list of events to be displayed.
     */
    public EventAdapter(Context context, List<Event> events) {
        this.context = context;
        this.events = events;
    }

    /* Return the total number of events in the <list>
    @return the total no. of events
    */
    @Override
    public int getCount() {
        return events.size();
    }

    /*
    Return the event at the specified position in the list.
    @param position The position of the event in the list.
    @return the event object
     */
    @Override
    public Object getItem(int position) {
        return events.get(position);
    }

    /*
    return the event object at the specified position
    @param position The position of the event in the list.
    @return the event object
     */
    @Override
    public long getItemId(int position) {
        return position;
    }

    /*
    Creates and returns the view for each event item in the list.
    @param position The position of the event in the list.
    @param convertView The view to be converted/populate
    @return the view for the event item
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.grid_item_event, parent, false);
        }

        Event event = events.get(position);

        TextView title = convertView.findViewById(R.id.title);
        TextView desc = convertView.findViewById(R.id.description);
        TextView date = convertView.findViewById(R.id.date);
        title.setText(event.getTitle());
        desc.setText(event.getDescription());
        date.setText(event.getDate() + " " + event.getTime());

        // Bind other views to display event details

        return convertView;
    }
}

