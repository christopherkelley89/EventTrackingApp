package com.zybooks.christopherkelley_eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private Button buttonLogin;
    private Button buttonRegister;
    private Button buttonForgotPassword;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize Views
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        buttonForgotPassword = findViewById(R.id.buttonForgotPassword);

        db = new DatabaseHelper(this);

        // Set click listener for the login button
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the username and password from user input
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();

                // Perform login validation
                if (validateLogin(username, password)) {
                    // Successful login toast
                    Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_LONG).show();

                    // Navigate to MainActivity
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Optional: Finish the LoginActivity to prevent going back to it with back button
                } else {
                    // Failed Login Toast (Invalid username or password)
                    Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set click listener for the register button
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to RegisterActivity
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        // Set click listener for the forgot password button
        buttonForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to PasswordResetActivity
                Intent intent = new Intent(LoginActivity.this, PasswordResetActivity.class);
                startActivity(intent);
            }
        });
    }

    /**
     * Validates the user login credentials.
     *
     * @param username The entered username.
     * @param password The entered password.
     * @return True if the credentials are valid, false otherwise.
     */
    private boolean validateLogin(String username, String password) {
        if (db.loginUser(username, password)) {
            // Retrieve the phone number for the logged-in user
            String phoneNumber = db.getPhoneNumber(username);

            // Store the phone number in SharedPreferences for later use
            SharedPreferences.Editor editor = getSharedPreferences("user_data", MODE_PRIVATE).edit();
            editor.putString("phone", phoneNumber);
            editor.apply();
            return true;
        } else {
            return false;
        }
    }
}
