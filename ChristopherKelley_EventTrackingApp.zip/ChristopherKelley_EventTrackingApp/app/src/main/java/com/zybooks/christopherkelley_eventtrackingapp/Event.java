package com.zybooks.christopherkelley_eventtrackingapp;

public class Event {
    private int id;                // Event ID
    private String title;          // Event title
    private String date;           // Event date
    private String time;           // Event time
    private String description;    // Event description

    public Event(int id, String title, String date, String time, String description) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
        this.description = description;
    }

    public int getId() {
        return id;    // Returns the event ID
    }

    public String getTitle() {
        return title;    // Returns the event title
    }

    public String getDate() {
        return date;    // Returns the event date
    }

    public String getTime() {
        return time;    // Returns the event time
    }

    public String getDescription() {
        return description;    // Returns the event description
    }
}
