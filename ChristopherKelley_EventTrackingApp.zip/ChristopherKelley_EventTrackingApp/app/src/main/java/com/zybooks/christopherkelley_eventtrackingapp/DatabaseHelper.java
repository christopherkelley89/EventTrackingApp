package com.zybooks.christopherkelley_eventtrackingapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "EventTrackerDB";
    private static final String TABLE_USER = "User";
    private static final String KEY_USER_ID = "id";
    private static final String KEY_FULL_NAME = "full_name";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PHONE_NUMBER = "phone_number";
    private static final String KEY_PASSWORD = "password";

    private static final String TABLE_EVENT = "Event";
    private static final String KEY_EVENT_ID = "id";
    private static final String KEY_TITLE = "title";
    private static final String KEY_DATE = "date";
    private static final String KEY_TIME = "time";
    private static final String KEY_DESCRIPTION = "description";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create User table
        String createUserTableQuery = "CREATE TABLE IF NOT EXISTS " + TABLE_USER + "("
                + KEY_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_FULL_NAME + " TEXT NOT NULL,"
                + KEY_EMAIL + " TEXT NOT NULL UNIQUE,"
                + KEY_PHONE_NUMBER + " TEXT NOT NULL,"
                + KEY_PASSWORD + " TEXT NOT NULL"
                + ")";
        db.execSQL(createUserTableQuery);

        // Create Event table
        String createEventTableQuery = "CREATE TABLE IF NOT EXISTS " + TABLE_EVENT + "("
                + KEY_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_TITLE + " TEXT NOT NULL,"
                + KEY_DATE + " TEXT NOT NULL,"
                + KEY_TIME + " TEXT NOT NULL,"
                + KEY_DESCRIPTION + " TEXT"
                + ")";
        db.execSQL(createEventTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENT);

        // Create tables again
        onCreate(db);
    }

    /*
    TODO:
    Create a new user in the user table
    @param fullName = The full name of the user
    @param email = The email of the user (must be unique)
    @param phone = The phone number of the user
    @param password = The password of the user
     */
    public void createUser(String fullName, String email, String phone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Create a ContentValues object to store the column-value pairs
        ContentValues values = new ContentValues();
        values.put(KEY_FULL_NAME, fullName);             // Insert the full name value
        values.put(KEY_EMAIL, email);                     // Insert the email value
        values.put(KEY_PHONE_NUMBER, phone);       // Insert the phone number value
        values.put(KEY_PASSWORD, password);        // Insert the password value

        // Insert the values into the User table
        db.insert(TABLE_USER, null, values);

        // Close the database connection
        db.close();
    }


    public boolean loginUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Define the columns to be retrieved from the User table
        String[] columns = {KEY_EMAIL};
        // Define the selection criteria
        String selection = KEY_EMAIL + " = ? AND " + KEY_PASSWORD + " = ?";
        // Define the selection arguments
        String[] selectionArgs = {email, password};
        // Perform the database query
        Cursor cursor = db.query(TABLE_USER, columns, selection, selectionArgs, null, null, null);
        // Get the count of the returned rows
        int count = cursor.getCount();
        // Close the cursor and database connection
        cursor.close();
        db.close();
        // Return true if the count is greater than 0 (user exists and credentials are valid),
        // ELSE return false
        return count > 0;
    }

    @SuppressLint("Range")
    public String getPhoneNumber(String email) {
        SQLiteDatabase db = this.getReadableDatabase(); // GET readable instance of the database
        String[] columns = {KEY_PHONE_NUMBER}; // DEFINE columns to retrieve
        String selection = KEY_EMAIL + " = ?"; // DEFINE selection criteria
        String[] selectionArgs = {email}; // Define the selection arguments
        Cursor cursor = db.query(TABLE_USER, columns, selection, selectionArgs, null, null, null); // Execute the query
        String phoneNumber = null; // Initialize the phone number variable
        if (cursor.moveToFirst()) {
            phoneNumber = cursor.getString(cursor.getColumnIndex(KEY_PHONE_NUMBER)); // Retrieve the phone number from the cursor
        }
        cursor.close(); // Close the cursor
        db.close(); // Close the database
        return phoneNumber; // Return the phone number
    }

    /*
        Update the users password
     */
    public int updatePassword(String email, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase(); // Get writable instance of the database
        ContentValues values = new ContentValues(); // Create ContentValues object to store the new password value
        values.put(KEY_PASSWORD, newPassword); // Set the new password value in the ContentValues object
        String whereClause = KEY_EMAIL + " = ?"; // Define the WHERE clause for the update operation
        String[] whereArgs = { email }; // Define WHERE arguments for the update operation
        int rowsAffected = db.update(TABLE_USER, values, whereClause, whereArgs); // Execute the update operation and get the number of affected rows
        db.close(); // Close the database

        return rowsAffected; // Return the number of affected rows
    }
    /**
     *TODO:
     * Creates a new event in the Event table.
     *
     * @param title       The title of the event.
     * @param date        The date of the event.
     * @param time        The time of the event.
     * @param description The description of the event.
     */
    public void createEvent(String title, String date, String time, String description) {
        SQLiteDatabase db = this.getWritableDatabase(); // Get writable instance of the database
        ContentValues values = new ContentValues(); // Create ContentValues object to store event data
        values.put(KEY_TITLE, title); // Set event title in the ContentValues object
        values.put(KEY_DATE, date); // Set event date in the ContentValues object
        values.put(KEY_TIME, time); // Set event time in the ContentValues object
        values.put(KEY_DESCRIPTION, description); // Set event description in the ContentValues object
        db.insert(TABLE_EVENT, null, values); // Insert the event data into the database
        db.close(); // Close the database
    }
    /*
        DELETE an event from the Event table
        @param eventId = The ID of the event to delete
     */
    public void deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase(); // Get a writable instance of the database
        String whereClause = KEY_EVENT_ID + " = ?"; // Define the WHERE clause for the delete operation
        String[] whereArgs = {String.valueOf(eventId)}; // Define the values for the WHERE clause
        db.delete(TABLE_EVENT, whereClause, whereArgs); // Delete the event from the database using the WHERE clause and arguments
        db.close(); // Close Database
    }
    /*
        Retrieve all events from event table
        @return List of events
     */
    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>(); // Create new ArrayList to store events
        SQLiteDatabase db = this.getReadableDatabase(); // Get readable instance of the DB
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EVENT, null); // Execute a raw query to retrieve all rows from the Event table

        if (cursor.moveToFirst()) { // Check if the cursor can move to the first row
            do {
                @SuppressLint("Range") int eventId = cursor.getInt(cursor.getColumnIndex(KEY_EVENT_ID)); // Retrieve the event ID from the cursor
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(KEY_TITLE)); // Retrieve the event title from the cursor
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(KEY_DATE)); // Retrieve the event date from the cursor
                @SuppressLint("Range") String time = cursor.getString(cursor.getColumnIndex(KEY_TIME)); // Retrieve the event time from the cursor
                @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)); // Retrieve the event description from the cursor

                Event event = new Event(eventId, title, date, time, description); // Create a new Event object with the retrieved data
                events.add(event); // Add the event to the events list
            } while (cursor.moveToNext()); // Move the cursor to the next row and repeat the loop
        }

        cursor.close(); // Close cursor to release resource
        db.close(); // Close Database
        return events; // Return the list of events
    }
}

