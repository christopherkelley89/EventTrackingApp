package com.zybooks.christopherkelley_eventtrackingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.view.View;
import android.widget.GridView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button buttonAddEvent, buttonDeleteEvent;
    GridView gridView;
    EventAdapter eventAdapter;
    DatabaseHelper db;
    List<Event> events;
    private static final int PERMISSION_REQUEST_SEND_SMS = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize Views
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonDeleteEvent = findViewById(R.id.buttonDeleteEvent);
        gridView = findViewById(R.id.gridViewEvents);

        db = new DatabaseHelper(this);
        events = db.getAllEvents();
        eventAdapter = new EventAdapter(this, events);
        gridView.setAdapter(eventAdapter);

        SharedPreferences sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE);
        String smsPermission = sharedPreferences.getString("smsPermission", "");

        if (smsPermission.equals("")){
            showSmsPermissionDialog();
        }else{
            if (smsPermission.equals("granted")){
                sendSMSNotifications();
            }else{
                if (isSmsPermissionGranted()) {
                    sendSMSNotifications();
                }
            }
        }


        // Check if the login button is present in the layout
        if (findViewById(R.id.buttonLogin) != null) {
            // Initialize the login button
            Button buttonLogin = findViewById(R.id.buttonLogin);

            // Set click listener for the login button
            buttonLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Start the LoginActivity
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
            });
        }
        buttonAddEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddEventActivity.class);
                startActivity(intent);
            }
        });

        List<Integer> selectedEventPositions = new ArrayList<>();
        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                // Mark the long-pressed event red
                view.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.markedColor));

                // Store the selected event position
                selectedEventPositions.add(position);
                return true;
            }
        });
        buttonDeleteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Delete the marked events
                for (int position : selectedEventPositions) {
                    // Delete the event at the specified position
                    deleteEvent(position);
                }

                // Clear the selected event positions
                selectedEventPositions.clear();

                // Update the GridView adapter to reflect the changes
                eventAdapter.notifyDataSetChanged();
            }
        });

    }

    /*
        Delete the event at the specified position from the database and event list
        @param The position of the event to delete in the event list
     */
    private void deleteEvent(int position) {
        // Get the event at the specified position
        Event eventToDelete = events.get(position);
        db.deleteEvent(eventToDelete.getId());

        // Remove the event from the events list
        events.remove(eventToDelete);
    }
    /*
        Checks if SMS permission is Granted!!!
        @return True if the permission is granted
        ELSE: False...
     */
    private boolean isSmsPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }
    /*
        Requests SMS Permissions from the user
     */
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
    }
    /*
        Shows the SMS Permission Dialog to the User
     */
    private void showSmsPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SMS Permission");
        builder.setMessage("This app requires SMS permission to send alerts. Grant permission?");
        builder.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                requestSmsPermission();
            }
        });
        builder.setNegativeButton("Deny", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "SMS permission denied. Alerts will not be sent.", Toast.LENGTH_SHORT).show();
                SharedPreferences.Editor editor = getSharedPreferences("user_data", MODE_PRIVATE).edit();
                editor.putString("smsPermission", "denied");
                editor.apply();
            }
        });
        builder.setCancelable(false);
        builder.show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // SMS permission granted, proceed with sending SMS alerts
                SharedPreferences.Editor editor = getSharedPreferences("user_data", MODE_PRIVATE).edit();
                editor.putString("smsPermission", "granted");
                editor.apply();
                sendSMSNotifications();
            } else {
                SharedPreferences.Editor editor = getSharedPreferences("user_data", MODE_PRIVATE).edit();
                editor.putString("smsPermission", "denied");
                editor.apply();
                // SMS permission denied, handle the denial gracefully
                Toast.makeText(this, "SMS permission denied. Alerts will not be sent!", Toast.LENGTH_SHORT).show();
            }
        }
    }
    /*
    Sends SMS notifications for events @Today
     */
    public void sendSMSNotifications() {
        // GET current date
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());

        // Retrieve the phone number from shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE);
        String phoneNumber = sharedPreferences.getString("phone", "");

        // Check each event for today's date and send SMS notifications
        for (Event event : events) {
            if (event.getDate().equals(currentDate)) {
                String message = "Event '" + event.getTitle() + "' is today! Do not forget about this event!.";
                sendSMS(phoneNumber, message);
            }
        }
    }

    /*
        Sends SMS message with specified message to the phone number of the user account in question
        @param phoneNumber = phone number to send the SMS to
        @param message = messageContent to send via SMS
     */
    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS notification sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "FAILED to send SMS notification", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }





}
