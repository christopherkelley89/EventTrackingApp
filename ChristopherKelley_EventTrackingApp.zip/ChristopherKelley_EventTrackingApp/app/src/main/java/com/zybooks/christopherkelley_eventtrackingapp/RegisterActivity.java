package com.zybooks.christopherkelley_eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText editFullName, editEmail, editPhone, editPassword, editConfirmPassword;
    Button buttonRegister;
    DatabaseHelper db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize UI elements
        editFullName = findViewById(R.id.editFullName);
        editEmail = findViewById(R.id.editEmail);
        editPhone = findViewById(R.id.phone);
        editPassword = findViewById(R.id.editPassword);
        editConfirmPassword = findViewById(R.id.editConfirmPassword);
        buttonRegister = findViewById(R.id.buttonRegister);

        // Initialize database helper
        db = new DatabaseHelper(this);

        // Set click listener for the Register button
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retrieve user input from EditText fields
                String fullName = editFullName.getText().toString();
                String email = editEmail.getText().toString();
                String phone = editPhone.getText().toString();
                String password = editPassword.getText().toString();
                String conPassword = editConfirmPassword.getText().toString();

                // Call the createUser method to register the user
                createUser(fullName, email, phone, password, conPassword);
            }
        });
    }

    // Method to create a new user
    private void createUser(String fullName, String email, String phone, String password, String conPassword) {
        if (!fullName.equals("") && !email.equals("") && !phone.equals("") && !password.equals("") && !conPassword.equals("")) {
            if (password.equals(conPassword)) {
                // CALL createUser method in DatabaseHelper to add the user to the database
                db.createUser(fullName, email, phone, password);
                Toast.makeText(getApplicationContext(), "User created successfully!", Toast.LENGTH_LONG).show();

                // Redirect to the LoginActivity after successful registration
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            } else {
                // Display an error message if passwords do not match
                Toast.makeText(getApplicationContext(), "Passwords do not match!", Toast.LENGTH_LONG).show();
            }
        } else {
            // Display an error message if any fields are left empty
            Toast.makeText(getApplicationContext(), "All fields are required!", Toast.LENGTH_LONG).show();
        }
    }
}
