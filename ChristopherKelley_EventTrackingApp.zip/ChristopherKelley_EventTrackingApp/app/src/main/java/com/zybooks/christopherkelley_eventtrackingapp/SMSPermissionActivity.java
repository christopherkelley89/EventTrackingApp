package com.zybooks.christopherkelley_eventtrackingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class SMSPermissionActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_SEND_SMS = 123;
    private Button buttonAllowPermission;
    private Button buttonDenyPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smspermission);

        // Initialize Views
        buttonAllowPermission = findViewById(R.id.buttonAllowPermission);
        buttonDenyPermission = findViewById(R.id.buttonDenyPermission);

        if (!isSmsPermissionGranted()) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
        } else {
            // SMS permission is already granted, proceed with sending SMS alerts
//            sendSMSAlerts();
        }
    }

    /**
     * Checks if the SMS permission is granted.
     *
     * @return True if the permission is granted, false otherwise.
     */
    private boolean isSmsPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // SMS permission granted, proceed with sending SMS alerts
//                sendSMSAlerts();
            } else {
                // SMS permission denied, handle the denial gracefully
                Toast.makeText(this, "SMS permission denied. SMS alerts will not be sent.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
