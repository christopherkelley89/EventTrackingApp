package com.zybooks.christopherkelley_eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PasswordResetActivity extends AppCompatActivity {
    EditText editEmail, editPassword, editConfirmPassword;
    Button buttonResetPassword, buttonGoBack;
    DatabaseHelper db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passwordreset);

        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        editConfirmPassword = findViewById(R.id.editConfirmPassword);
        buttonResetPassword = findViewById(R.id.buttonResetPassword);
        buttonGoBack = findViewById(R.id.buttonGoBack);
        db = new DatabaseHelper(this);
        buttonResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getEmail = editEmail.getText().toString();
                String getPassword = editPassword.getText().toString();
                String getConPassword = editConfirmPassword.getText().toString();

                if (!getEmail.equals("") && !getPassword.equals("") && !getConPassword.equals("")){
                    if (getPassword.equals(getConPassword)){
                        int rowsAffected = db.updatePassword(getEmail, getPassword);

                        if (rowsAffected > 0) {
                            // Password updated successfully
                            Toast.makeText(getApplicationContext(), "Password updated", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(PasswordResetActivity.this, LoginActivity.class);
                            startActivity(intent);
                        } else {
                            // Email not found in the database
                            Toast.makeText(getApplicationContext(), "Email does not exist", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(PasswordResetActivity.this, "Password do not match!", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(PasswordResetActivity.this, "All fields are required!", Toast.LENGTH_LONG).show();
                }
            }
        });
        buttonGoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PasswordResetActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

    }
}

