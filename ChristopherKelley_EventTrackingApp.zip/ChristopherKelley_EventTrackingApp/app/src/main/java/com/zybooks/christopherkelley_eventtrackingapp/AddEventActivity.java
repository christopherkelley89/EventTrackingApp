package com.zybooks.christopherkelley_eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

public class AddEventActivity extends AppCompatActivity {
    Button btn_pick_date, add;
    TextView tv_selected_date;
    String selectedDate = "";
    String selectedTime = "";
    EditText title, description;
    TimePicker time_picker;
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        //initialize the views
        btn_pick_date = findViewById(R.id.btn_pick_date);
        tv_selected_date = findViewById(R.id.tv_selected_date);
        title = findViewById(R.id.title);
        description = findViewById(R.id.description);
        time_picker = findViewById(R.id.time_picker);
        add = findViewById(R.id.add);

        db = new DatabaseHelper(this);

        btn_pick_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a Calendar instance to get the current date
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

                // Create a DatePickerDialog to show the date picker dialog
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        AddEventActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                // Handle the selected date
                                selectedDate = formatDate(year, month, dayOfMonth);
                                tv_selected_date.setText("Selected Date: " + selectedDate);
                            }
                        },
                        year,
                        month,
                        dayOfMonth
                );

                // Show the date picker dialog
                datePickerDialog.show();

            }
        });
        //Set listener for the time picker
        time_picker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                // Handle the selected time
                selectedTime = formatTime(hourOfDay, minute);
            }
        });
        // Set the initial value of selectedTime to default time (12:00)
        selectedTime = formatTime(12, 0);

        //TODO: Set click listener for the add button
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getTitle = title.getText().toString();
                String getDesc = description.getText().toString();

                if (!getTitle.equals("") && !getDesc.equals("") && !selectedDate.equals("") && !selectedTime.equals("")){
                    db.createEvent(getTitle, selectedDate, selectedTime, getDesc);
                    Toast.makeText(getApplicationContext(), "Event added successfully!", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(AddEventActivity.this, MainActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), "All fields are required!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /*
        Format the date MM/DD/yyyy
        @param year = selectedYear
        @param month = selectedMonth
        @param dayOfMonth = selectedDayOfMonth
        @return formattedDate string
     */
    private String formatDate(int year, int month, int dayOfMonth) {
        // Format the selected date as desired (e.g., "MM/DD/yyyy")
        String formattedDate = String.format(Locale.US, "%02d/%02d/%04d", (month + 1), dayOfMonth, year);
        return formattedDate;
    }
    /*
        * Formats the selected time as desired (e.g., "HH:mm")Format the selected time as "HH:mm"
        * @param HourOfDay = selectedHour
        * @param minute = selectedMinute
        * @return formattedTime string
     */
    private String formatTime(int hourOfDay, int minute) {
        // Format the selected time as "HH:mm"
        String formattedTime = String.format(Locale.US, "%02d:%02d", hourOfDay, minute);
        return formattedTime;
    }
}